-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 23, 2022 at 07:21 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `parent_id`, `image`, `description`, `slug`, `active`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 'Tranh Loài Hoa', 0, '/storage/upload/2022/03/17/115HC929D3_hoa.jpg', 'Danh muc tranh Loài Hoa', 'tranh-loai-hoa', 1, 0, '2022-03-17 00:07:44', '2022-03-19 03:42:00'),
(2, 'Tranh Phong Cảnh', 0, '/storage/upload/2022/03/17/B9BA7n6BmM_phong_canh.png', 'Danh muc tranh Phong Cảnh', 'tranh-phong-canh', 1, 0, '2022-03-17 00:17:58', '2022-03-19 03:42:15'),
(3, 'Hoa Sen', 1, '', '', 'hoa-sen', 1, 0, '2022-03-17 03:44:36', '2022-03-17 03:44:36'),
(4, 'Hoa Hồng', 1, '', 'Danh muc tranh Hoa Hồng', 'hoa-hong', 1, 0, '2022-03-17 23:37:38', '2022-03-17 23:37:38'),
(5, 'Hoa Lan', 1, '', 'Danh muc tranh Hoa Lan', 'hoa-lan', 1, 0, '2022-03-18 02:42:12', '2022-03-18 02:42:12'),
(6, 'Tranh Cô Gái', 0, '/storage/upload/2022/03/19/bdc7nEDchD_co_gai.png', 'Danh mục Tranh Cô Gái', 'tranh-co-gai', 1, 0, '2022-03-19 03:42:50', '2022-03-19 03:42:50'),
(7, 'Mua Thu', 2, '', '', 'mua-thu', 1, 0, '2022-03-21 20:06:48', '2022-03-21 20:06:48');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(8, '2014_10_12_000000_create_users_table', 1),
(9, '2014_10_12_100000_create_password_resets_table', 1),
(10, '2019_08_19_000000_create_failed_jobs_table', 1),
(11, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(13, '2022_03_14_095703_create_categories_table', 2),
(14, '2022_03_16_065542_create_products_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cat_id` int(11) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `discount` decimal(10,0) NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `view` int(11) NOT NULL,
  `buy` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `cat_id`, `price`, `discount`, `slug`, `thumbnail`, `images`, `description`, `status`, `view`, `buy`, `created_at`, `updated_at`) VALUES
(1, 'Bộ ba Tranh Trái Tim Tình yêu', 4, '1090000', '0', 'bo-ba-tranh-trai-tim-tinh-yeu', '/storage/upload/2022/03/18/GCbmDH64NE_bo_ba_hoa_hong_trai_timx300.jpg', '/storage/upload/2022/03/18/7a3c45d105_bo_ba_hoa_hong_trai_timx500.jpg,/storage/upload/2022/03/18/aCdeE2dg0g_bo_ba_hoa_hong_trai_timx500x1.jpg', '', 1, 0, 0, '2022-03-18 00:00:31', '2022-03-18 03:08:06'),
(2, 'Tranh Đầm Hoa Sen - VR201', 3, '1090000', '0', 'tranh-dam-hoa-sen-vr201', '/storage/upload/2022/03/18/0engmg3a3E_tranh-dam-hoa-sen-VR20110227901_288x.jpg', '/storage/upload/2022/03/18/HDBN5h64M0_tranh-dam-hoa-sen-VR20110227901_720x.jpg,/storage/upload/2022/03/18/h7EBaH5BnD_tranh-dam-hoa-sen-VR20110227901_720x1.jpg', '', 1, 0, 0, '2022-03-18 00:02:57', '2022-03-18 03:07:30'),
(3, 'Tranh Hoa Sen trắng VZ232', 3, '1940000', '0', 'tranh-hoa-sen-trang-vz232', '/storage/upload/2022/03/18/764MG1eC2B_tranh-hoa-sen-trang-VZ23210011589_360x.jpg', '/storage/upload/2022/03/23/e0EdgNcE5H_tranh-hoa-sen-trang-VZ23210011589_576x.jpg,/storage/upload/2022/03/23/58m6HmMaah_tranh-hoa-sen-trang-VZ23210011589_576x1.jpg', '', 1, 0, 0, '2022-03-18 00:56:06', '2022-03-22 19:42:04'),
(4, 'Bộ 5 Tranh Những Chậu Hoa Lan - VV339', 5, '1260000', '120000', 'bo-5-tranh-nhung-chau-hoa-lan-vv339', '/storage/upload/2022/03/18/Anh14E44HE_bo_5_tranh_nhung_chau_hoa_lan-10064678_288x.jpg', '/storage/upload/2022/03/18/hhE9Dag8nd_bo_5_tranh_nhung_chau_hoa_lan-10064678.jpg,/storage/upload/2022/03/18/AeHcE7nh5h_bo_5_tranh_nhung_chau_hoa_lan-10064678x1.jpg', '', 1, 0, 0, '2022-03-18 02:34:08', '2022-03-21 07:32:39'),
(5, 'Tranh Sơn Dầu Phong Cảnh Thu Vàng - SH150', 7, '3900000', '0', 'tranh-son-dau-phong-canh-thu-vang-sh150', '/storage/upload/2022/03/19/mnAb2677nA_tranh_son_dau_thu_vang_SH150_360x.jpg', '/storage/upload/2022/03/19/3MaE1DgaB1_tranh_son_dau_thu_vang_SH150_750x.jpg,/storage/upload/2022/03/19/dHh14Eh677_tranh_son_dau_thu_vang_SH150_750x1.jpg', '', 1, 0, 0, '2022-03-19 11:11:03', '2022-03-21 20:07:06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@gmail.com', NULL, '$2y$10$G05VIu/r5dkWHKhC0kWnRuZXGSQaQtr/B1fUpzn0MhqY/IwvjJn/y', NULL, '2022-03-17 06:31:31', '2022-03-17 06:31:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_slug_unique` (`slug`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
