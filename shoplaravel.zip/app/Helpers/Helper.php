<?php
namespace App\Helpers;

class Helper
{
	
	public static function activeCategory($status='')
	{
		return ($status==0 ? '<span class="btn btn-danger btn-xs">NOT</span>':
			'<span class="btn btn-success btn-xs">YES</span>'
		);
	}
	
	public static function randomCharacter($name='')
	{
		$arr = array('a','A','b','B','c','C','d','D','e','E','g','G','h','H','m','M','n','N','0','1','2','3','4','5','6','7','8','9');
		$str = '';
		$len = count($arr);
		for ($i=0; $i < 10; $i++) { 
			$str .= $arr[rand(0,$len - 1)];
		}
		$str .= '_'.$name;
		return $str;
	}
	public static function Menu($menu,$parent_id=0)
	{
		$html = '<ul class="header__submenu list-menu list-menu--disclosure caption-large motion-reduce" role="list" tabindex="-1">';
		foreach($menu as $key => $parent){
			if($parent->parent_id==$parent_id){
				if(self::hasMenuChild($menu,$parent->id)){
					$html .= '
						<li>
						<details>
							<summary class="header__menu-item link link--text list-menu__item focus-inset caption-large">'.$parent->name.'
							<svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-caret" viewBox="0 0 10 6">
							<path fill-rule="evenodd" clip-rule="evenodd" d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z" fill="currentColor">
							</path></svg></summary>
							<ul class="header__submenu list-menu motion-reduce">
                                <li><a href="/collections/'.$parent->id.'-'.$parent->slug.'" class="header__menu-item list-menu__item link link--text focus-inset caption-large">Tất Cả</a></li>';
					foreach($menu as $sub){
						if($sub->parent_id==$parent->id){
							$html .= '
								<li>
									<a href="/collections/'.$sub->id.'-'.$sub->slug.'" class="header__menu-item list-menu__item link link--text focus-inset caption-large">'.$sub->name.'</a>
								</li>
							';
						}
					}
					$html .= '</ul></details></li>';
				}else{
					$html .= '<li><a href="/collections/'.$parent->id.'-'.$parent->slug.'" class="header__menu-item list-menu__item link link--text focus-inset caption-large">'.$parent->name.'</a></li>';
				}
			}
		}
		return $html;
	}
	public static function hasMenuChild($menu,$id){
		foreach($menu as $item){
			if($item->parent_id == $id){
				return true;
			}
		}
		return false;
	}
	public static function displayPrice($price,$discount)
	{
		$html = '';
		if($discount > 0){
			$html .= '
				<div class="price price--on-sale">
					<dl>
						<div class="price__sale">
							<dd class="price__compare">
								<s class="price-item price-item--regular">'.number_format($price).'</s>
							</dd>
							<dd>
								<span class="price-item price-item--sale">'.number_format($price - $discount).' VND</span>
							</dd>
						</div>
					</dl>
				</div>
			';
		}else{
			$html .= '
				<div class="price">
					<dl>
						<div class="price__regular">
							<dd>
								<span class="price-item price-item--regular">'.number_format($price).' VND</span>
							</dd>
						</div>
					</dl>
				</div>
			';
		}
		return $html;
	}
}