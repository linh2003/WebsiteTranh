<?php
namespace App\Http\Services\Category;

use App\Models\Categories;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

class CategoryService
{
	
	public function getAll($input=1)
	{
		$result = '';
		if ($input==0) {
			$result = Categories::where('parent_id',$input)->get();
		}else{
			$result = Categories::orderbyDesc('id')->get();
		}
		return $result;
	}
	public function getListInput($input=1)
	{
		$result = '';
		if ($input==0) {
			$result = Categories::where('parent_id',$input)->get();
		}else{
			$result = Categories::orderbyDesc('id')->paginate($input);
		}
		return $result;
	}
	public function create($request)
	{
		try{
			Categories::create([
				'name' 			=> (string)$request->input('name'),
				'parent_id' 	=> (int)$request->input('parent_id'),
				'image' 		=> (string)$request->input('thumb'),
				'description' 	=> (string)$request->input('desc'),
				'slug' 			=> Str::slug($request->input('name'),'-'),
				'active' 		=> (int)$request->input('status'),
				'sort_order' 	=> (int)$request->input('sort_order'),
			]);
			Session::flash('success','Insert data success');
		}catch(\Exception $err){
			Session::flash('error','Insert data fail');
			return false;
		}
		return true;
	}
	public function update($request,$menu)
	{
		try{
			$menu->name 		= (string)$request->input('name');
			if($request->input('parent_id') != $menu->id){
				$menu->parent_id 	= (int)$request->input('parent_id');
			}
			if(!empty($request->input('thumb'))){
				
				$menu->image 		= (string)$request->input('thumb');
			}
			$menu->description 	= (string)$request->input('desc');
			$menu->slug 		= (string)$request->input('slug');
			$menu->active 		= (int)$request->input('status');
			$menu->sort_order 	= (int)$request->input('sort_order');
			$menu->save();
			Session::flash('success','Update data success');
		}catch(\Exception $err){
			Session::flash('error','Update data fail');
			return false;
		}
		return true;
	}
	public function destroy($request){
		$id = $request->input('id');
		$menu = Categories::where('id',$id)->first();
		if ($menu) {
            Session::flash('success','Delete data success');
			return Categories::where('id',$id)->orWhere('parent_id',$id)->delete();
		}
		return false;
	}
	public function getCatFormSlug($id){
		$cat = Categories::where('id',$id)->where('active',1)->firstOrFail();
		if($cat->parent_id == 0){
			$child = Categories::where('parent_id',$cat->id)->where('active',1)->get();
			return $child;
		}else{
			return $cat;
		}
	}
	public function getProducts($request,$cat){
		$result = '';
		$min_price = (double)$request->input('min_price');
		$max_price = (double)$request->input('max_price');
		if($min_price > $max_price){
			$result = $cat->products()->where('price','>=',$min_price)->orderbyDesc('id')->paginate(12);
		}else if($min_price && $max_price){
			$result = $cat->products()->whereBetween('price',[$min_price,$max_price])->orderbyDesc('id')->paginate(12);
		}else if($min_price==0 && $max_price){
			$result = $cat->products()->where('price','<=',$max_price)->orderbyDesc('id')->paginate(12);
		}else{
			$result = $cat->products()->where('status',1)->orderByDesc('id')->paginate(12);
		}
		return $result;
	}
	public function getProductRelated($request,$cat,$id_product){
		$result = $cat->products()->where('status',1)->orderByDesc('id')->limit(8)->get();
		return $result;
	}
}