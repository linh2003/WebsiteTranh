<?php
namespace App\Http\Services;
use Illuminate\Support\Facades\Session;
use App\Helpers\Helper;

class UploadService
{
	public function store($request){
		//dd($request->input('file'));
		//check exists file
		if ($request->hasFile('file')) {
			try{
				//get extension file
				$extension = $request->file('file')->extension();
				//check extension file are jpg | png | gif | jpeg
				$pathFull = 'upload/'.date('Y/m/d');;
				if ($extension == 'jpg' || $extension == 'png' || $extension == 'gif' || $extension == 'jpeg') {
					$name = $request->file('file')->getClientOriginalName();
					$name = Helper::randomCharacter($name);
					$path = 'public/'.$pathFull;
					$request->file('file')->storeAs($path,$name);
				}else{
					return false;
				}
				Session::flash('success','Upload file success');
				$path = '/storage/'.$pathFull.'/'.$name;
				return $path;
			}catch(\Exception $error){
				Session::flash('error','Upload file fail');
				return false;
			}
		}
	}
	public function storeMulti($request){
		$arr = $request->file();
		if (count($arr)>0) {
			// $arr = $request->file();
			try{
				$patharr = '';
				$i=1;
				foreach($arr as $key => $val){
					//get extension file
					$extension = $val->extension();
					//check extension file are jpg | png | gif | jpeg
					$pathFull = 'upload/'.date('Y/m/d');;
					if ($extension == 'jpg' || $extension == 'png' || $extension == 'gif' || $extension == 'jpeg') {
						$name = $val->getClientOriginalName();
						$name = Helper::randomCharacter($name);
						$path = 'public/'.$pathFull;
						$val->storeAs($path,$name);
						$patharr .= '/storage/'.$pathFull.'/'.$name . ($i<count($arr)?',':'');
						$i++;
					}else{
						return false;
					}
				}
				Session::flash('success','Upload file success');
				//$path = '/storage/'.$pathFull.'/'.$name;
				return $patharr;
			}catch(\Exception $error){
				Session::flash('error','Upload file fail');
				return false;
			}
		}
	}
}