<?php
namespace App\Http\Services\Cart;

use App\Models\Product;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Arr;

class CartService
{
	
	public function create($request)
	{
		$qty 	= (int)$request->input('product_qty');
		$id 	= $request->input('id');
		$product = Product::select('id','name','thumbnail')
		->where('id',$id)
		->get();
		Session::put('cart_status',[
			'status' =>	true,
			'product' => $product
		]);
		$carts 	= Session::get('carts');
		if(!isset($carts)){
			Session::put('carts',[
				$id => $qty
			]);
		}else{
			$exists = Arr::exists($carts,$id);
			if($exists){
				$carts[$id] += $qty;
				Session::put('carts',$carts);
			}else{
				$carts[$id] = $qty;
				Session::put('carts',$carts);
			}
		}
		return true;
	}
	public function getProducts(){
		$carts = Session::get('carts');
		if(is_null($carts)){
			return [];
		}
		$product_id = array_keys($carts);
		return Product::select('id','name','thumbnail','price','discount','slug')
		->whereIn('id',$product_id)
		->get();
	}
	public function update($request){
		$carts = Session::get('carts');
		$update = $request->input('updates');
		foreach($carts as $key => $item){
			if($update[$key] != $item){
				if($update[$key] == 0){
					unset($carts[$key]);
				}else{
					$carts[$key] = $update[$key];
				}
			}
		}
		Session::put('carts',$carts);
		return true;
	}
	public function remove($id){
		$carts = Session::get('carts');
		if($id == 0){
			foreach($carts as $key => $val){
				unset($carts[$key]);
			}
		}else{
			unset($carts[$id]);
		}
		Session::put('carts',$carts);
		return true;
	}
}