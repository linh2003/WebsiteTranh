<?php
namespace App\Http\Services\Product;

use App\Models\Product;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

class ProductService
{
	
	public function getListInput($item=3)
	{
		$result = Product::orderbyDesc('id')->paginate($item);
		return $result;
	}
	public function getListLimit($limit=3)
	{
		$result = Product::orderbyDesc('id')->offset(0)->limit($limit)->get();
		return $result;
	}
	public function getProducts($request){
		$result = '';
		$min_price = (double)$request->input('min_price');
		$max_price = (double)$request->input('max_price');
		if($min_price > $max_price){
			echo 'min > max';
			$result = Product::where('price','>=',$min_price)->orderbyDesc('id')->paginate(12);
		}else if($min_price < $max_price){
			$result = Product::whereBetween('price',[$min_price,$max_price])->orderbyDesc('id')->paginate(12);
		}else if($min_price==0 && $max_price){
			$result = Product::where('price','<=',$max_price)->orderbyDesc('id')->paginate(12);
		}else{
			$result = Product::orderbyDesc('id')->paginate(4);
		}
		//dd($result);
		return $result;
	}
	public function create($request)
	{
		$price 		= (double)$request->input('price');
		$discount 	= $request->input('discount');
		if(empty($discount)){
			$discount = 0;
		}else{
			$discount = (double)$discount;
		}
		if (!$this->validatePrice($price,$discount)) {
			Session::flash('error','Discount must smaller than price');
			return false;
		}
		try{
			Product::create([
				'name' 			=> (string)$request->input('name'),
				'cat_id' 		=> (int)$request->input('cat_id'),
				'price' 		=> $price,
				'discount' 		=> $discount,
				'thumbnail' 	=> (string)$request->input('thumb'),
				'images' 		=> (string)$request->input('images'),
				'slug' 			=> Str::slug($request->input('name'),'-'),
				'description' 	=> (string)$request->input('description'),
				'status' 		=> (string)$request->input('status'),
				'view' 			=> 0,
				'buy' 			=> 0,
			]);
			Session::flash('success','Insert data success');
		}catch(\Exception $err){
			dd($err->getMessage());
			Session::flash('error','Insert data fail');
			return false;
		}
		return true;
	}
	protected function validatePrice($price,$discount)
	{
		if (($price >= 0) && ($discount >= 0) && ($discount < $price)) {
			return true;
		}
		return false;
	}
	public function update($request,$product)
	{
		try{
			$product->name 		= (string)$request->input('name');
			$product->cat_id 	= (int)$request->input('cat_id');
			if(!empty($request->input('thumb'))){
				$product->thumbnail = (string)$request->input('thumb');
			}
			if(!empty($request->input('images'))){
				$product->images = (string)$request->input('images');
			}
			$product->price = (string)$request->input('price');
			if(!empty($request->input('discount'))){
				$product->discount = (double)$request->input('discount');
			}else{
				$product->discount = 0;
			}
			$product->description 	= (string)$request->input('desc');
			$product->slug 			= (string)$request->input('slug');
			$product->status 		= (int)$request->input('status');
			$product->save();
			Session::flash('success','Update data success');
		}catch(\Exception $err){
			Session::flash('error','Update data fail');
			return false;
		}
		return true;
	}
	public function destroy($request){
		$id = $request->input('id');
		$item = Product::where('id',$id)->first();
		if($item) {
            Session::flash('success','Delete data success');
			return Product::where('id',$id)->delete();
		}
		return false;
	}
	public function getInfo($slug){
		$result = Product::where('slug',$slug)->where('status',1)->firstOrFail();
		return $result;
	}
	public function getInfoID($id){
		$result = Product::where('id',$id)->get();
		return $result;
	}
	public function search($request){
		$q = $request->input('search');
		$result = Product::select('id','name','price','discount','thumbnail','slug')
		->where('name','like','%'.$q.'%')
		->where('status',1)
		->orderByDesc('id')->paginate(4);
		return $result;
	}
}