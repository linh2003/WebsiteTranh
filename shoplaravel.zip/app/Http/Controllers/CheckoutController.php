<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CheckoutController extends Controller
{
    public function index(){
        return view('main.checkout',[
            'title' => 'Đặt hàng'
        ]);
    }
    public function findPhone(Request $request){
        dd($request);
    }
}
