<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Services\Product\ProductService;

class SearchController extends Controller
{
    protected $productService;
    public function __construct(ProductService $productService)
	{
		$this->productService 	= $productService;
	}
    public function index(Request $request){
        $result = $this->productService->search($request);
        $count = count($result);
        $key = $request->input('search');
        $title = 'Kết quả tìm kiếm ' .$key;
        return view('main.search',[
            'title' => $title,
            'product' => $result,
            'key' => $key,
            'count' => $count
        ]);
    }
}
