<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Services\Category\CategoryService;
use App\Http\Services\Product\ProductService;
use App\Models\Product;
use App\Models\Categories;

class ProductsController extends Controller
{
	protected $catService;
	protected $productService;
	
	public function __construct(CategoryService $catService,ProductService $productService)
	{
		$this->catService 		= $catService;
		$this->productService 	= $productService;
	}
	//Display all product
    public function index(Request $request,$slug){
		$product_info = $this->productService->getInfo($slug);
		$id = $product_info->cat_id;
		$cat = $this->catService->getCatFormSlug($id);
		$product = $this->catService->getProductRelated($request,$cat,$product_info->id);
		$images = explode(',',$product_info->images);
		return view('main.product',[
			'title' 		=> $product_info->name,
			'product_info' 	=> $product_info,
			'images' 		=> $images,
			'product' 		=> $product
		]);
	}
}
