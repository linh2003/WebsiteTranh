<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Services\Category\CategoryService;
use App\Http\Services\Product\ProductService;
use App\Models\Categories;

class CategoryController extends Controller
{
	protected $catService;
	protected $productService;
	
	public function __construct(CategoryService $catService, ProductService $productService)
	{
		$this->catService 		= $catService;
		$this->productService 	= $productService;
	}
	//Display all product
    public function index(Request $request){
		$input = [];
		if($request->input('min_price')){
			$input['min_price'] = $request->input('min_price');
		}
		if($request->input('max_price')){
			$input['max_price'] = $request->input('max_price');
		}
		$input['title'] = 'Tất Cả Sản Phẩm';
		$product = $this->productService->getProducts($request);
		$input['product'] = $product;
		return view('main.category',$input);
	}
	//Display product follow category
	public function show(Request $request,$id){
		$cat = $this->catService->getCatFormSlug($id);
		$product = $this->catService->getProducts($request,$cat);
		$input = [];
		if($request->input('min_price')){
			$input['min_price'] = $request->input('min_price');
		}
		if($request->input('max_price')){
			$input['max_price'] = $request->input('max_price');
		}
		$input['title'] = $cat->name;
		$input['slug'] = $cat->slug;
		$input['product'] = $product;
		return view('main.category',$input);
	}
}
