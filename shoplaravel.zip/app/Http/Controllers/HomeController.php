<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Services\Category\CategoryService;
use App\Http\Services\Product\ProductService;

class HomeController extends Controller
{
	protected $catService;
	protected $productService;
	
	public function __construct(CategoryService $catService, ProductService $productService)
	{
		$this->catService 		= $catService;
		$this->productService 	= $productService;
	}
    public function index(){
		$cat 		= $this->catService->getListInput(0);
		$product 	= $this->productService->getListLimit(8);
		return view('main.home',[
			'title' 		=> 'Tranh Canvas Trang Trí, Tranh Treo Tường',
			'cat' 			=> $cat,
			'product_grid' 	=> $product,
		]);
	}
}
