<?php

namespace App\Http\Controllers\Admin\Users;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function index(){
		if (Auth::check()) {
			return redirect()->route('admin');
		}else{
			return view('admin.users.login',[
				'title' => 'Login'
			]);
		}		
	}
	public function store(Request $request){
		$credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);
		if (Auth::attempt($credentials)) {
            return redirect()->route('admin');
        }
		$request->session()->flash('error', 'Email or password incorrect');
		return redirect()->back();
	}
	public function logout(Request $request)
	{
		Auth::logout();
		$request->session()->invalidate();
		$request->session()->regenerateToken();
		return redirect()->route('login');;
	}
}
