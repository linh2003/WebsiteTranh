<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Product\CreateFormRequest;
use App\Http\Services\Product\ProductService;
use App\Http\Services\Category\CategoryService;
use App\Models\Product;

class ProductController extends Controller
{
	protected $catService;
	protected $productService;
	private $parent_cat;
	private $cat;
	public function __construct(CategoryService $catService, ProductService $productService)
	{
		$this->catService = $catService;
		$this->productService = $productService;
		$this->parent_cat = $this->catService->getAll(0);
		$this->cat = $this->catService->getAll();
	}

    public function index()
    {
        $product = $this->productService->getListInput();
		return view('admin.product.list',[
			'title' 		=> 'Product',
			'breadcrumb' 	=> 'Product',
			'cat' 			=> $this->cat,
			'product' 		=> $product,
		]);
    }

    public function add()
    {
		return view('admin.product.add',[
			'title' 		=> 'Add Product',
			'breadcrumb' 	=> 'Product',
			'parent_cat' 	=> $this->parent_cat,
			'cat' 			=> $this->cat,
		]);
    }

    public function store(CreateFormRequest $request)
    {
        $result = $this->productService->create($request);
		if(!$result){
			return redirect()->back();
		}
		return redirect()->route('product');
    }

    public function edit(Product $product)
    {
		return view('admin.product.edit',[
			'title' 		=> 'Edit Product '.$product->name,
			'parent_cat' 	=> $this->parent_cat,
			'cat' 			=> $this->cat,
			'product' 		=> $product,
			'breadcrumb' 	=> 'Category',
		]);
    }

    public function update(Product $product,CreateFormRequest $request)
    {
        $this->productService->update($request,$product);
		
		return redirect()->route('product');
    }

    public function destroy(Request $request)
    {
        $result = $this->productService->destroy($request);
		if ($result) {
			return response()->json([
				'error' 	=> false,
				'message' 	=> 'Delete item success'
			]);
		}else{
			return response()->json([
				'error' 	=> true
			]);
		}
    }
}
