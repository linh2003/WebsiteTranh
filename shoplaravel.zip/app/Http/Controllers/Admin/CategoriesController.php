<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Category\CreateFormRequest;
use App\Http\Services\Category\CategoryService;
use App\Models\Categories;

class CategoriesController extends Controller
{
	protected $catService;
	public function __construct(CategoryService $catService)
	{
		$this->catService = $catService;
	}
    public function index(){
		$cat = $this->catService->getListInput(10);
		return view('admin.category.list',[
			'title' 		=> 'Category',
			'breadcrumb' 	=> 'Category',
			'cat' 			=> $cat,
		]);
	}
	public function add(){
		$parent_cat = $this->catService->getListInput(0);
		return view('admin.category.add',[
			'title' 		=> 'Add Category',
			'breadcrumb' 	=> 'Category',
			'parent_cat' 	=> $parent_cat
		]);
	}
	public function store(CreateFormRequest $request){
		//dd($request->input());
		$result = $this->catService->create($request);
		
		return redirect()->route('category');
	}
	public function destroy(Request $request){
		$result = $this->catService->destroy($request);
		if ($result) {
			return response()->json([
				'error' 	=> false,
				'message' 	=> 'Delete item success'
			]);
		}else{
			return response()->json([
				'error' 	=> true
			]);
		}
	}
	public function edit(Categories $menu){
		$parent_cat = $this->catService->getListInput(0);
		return view('admin.category.edit',[
			'title' 		=> 'Edit Category ' .$menu->name,
			'menu' 			=> $menu,
			'parent_cat' 	=> $parent_cat,
			'breadcrumb' 	=> 'Category',
		]);
	}
	public function update(Categories $menu,CreateFormRequest $request){
		$this->catService->update($request,$menu);
		
		return redirect()->route('category');
	}
}
