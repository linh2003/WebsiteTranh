<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Services\UploadService;

class UploadController extends Controller
{
	protected $upload;
	public function __construct(UploadService $upload)
	{
		$this->upload = $upload;
	}
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
		// dd($request->file());
		// $arr = $request->file();
		// foreach($arr as $key => $val){
			// var_dump($val->extension());
			// die();
		// }
		$upload = $this->upload->storeMulti($request);
		//dd($upload);
        if($upload != false){
			return response()->json([
				'error' => false,
				'url' 	=> $upload
			]);
		}
		return response()->json([
			'error' => true,
			'message' => 'Extension file must as jpg, png, gif format',
		]);
    }

}
