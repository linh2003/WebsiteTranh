<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Services\Cart\CartService;
use Illuminate\Support\Facades\Session;

class CartController extends Controller
{
	protected $cartService;
	
	public function __construct(CartService $cartService)
	{
		$this->cartService = $cartService;
	}
    public function index(Request $request){	
		$result = $this->cartService->create($request);
		return redirect()->back();
	}
	public function show(Request $request){		
		$carts = Session::get('carts');
		$products = $this->cartService->getProducts();
		return view('main.cart',[
			'title' 	=> 'Giỏ Hàng Của Bạn',
			'products' 	=> $products,
			'carts' 	=> $carts,
		]);
	}
	public function update(Request $request){
		$this->cartService->update($request);
		return redirect('/cart');
	}
	public function remove(Request $request,$id=0){
		$this->cartService->remove($id);
		return redirect('/cart');
	}
}
