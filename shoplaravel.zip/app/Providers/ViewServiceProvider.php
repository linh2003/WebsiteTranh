<?php
 
namespace App\Providers;
 
use App\View\Composers\MenuComposer;
use App\View\Composers\CartComposer;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
 
class ViewServiceProvider extends ServiceProvider
{

    public function register()
    {
        //
    }

    public function boot()
    {
        // Using class based composers...
        View::composer('main.header', MenuComposer::class);
		View::composer('main.footer', MenuComposer::class);
		View::composer('main.sidebar', MenuComposer::class);
		//View::composer('main.main', CartComposer::class);
    }
	// private function composerHeader(){
		// View::composer('main.header', MenuComposer::class);
	// }
	// private function composerFooter(){
		// View::composer('main.footer', MenuComposer::class);
	// }
	// private function composerSidebar(){
		// View::composer('main.sidebar', MenuComposer::class);
	// }
}