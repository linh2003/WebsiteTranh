<?php
 
namespace App\View\Composers;

use App\Models\Categories;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\View\View;

class MenuComposer{

    public function __construct()
    {
        
    }
 
    public function compose(View $view)
    {
		//get all category
		$menu = Categories::select('id','name','parent_id','slug')->where('active',1)->orderBy('sort_order')->get();
		//get count product of category
		$countProduct = [];
		foreach($menu as $item){
			if($item->parent_id != 0){
				$count = DB::table('products')->where('cat_id',$item->id)->count();
				$countProduct[$item->id] = $count;
				if(!isset($countProduct[$item->parent_id])){
					$countProduct[$item->parent_id] = $count;
				}else{
					$countProduct[$item->parent_id] += $count;
				}
			}
		}
		//get session for cart notification
		$cart_notify = [];
		$cart_status = Session::get('cart_status');
        $sum = Session::get('carts');
		$total = 0;
		if(!is_null($sum)){
			foreach($sum as $val){
				$total += $val;
			}
		}
		$cart_notify['cart_status'] = $cart_status;
		$cart_notify['total'] = $total;
		
		$data = array('menu'=>$menu,'countProduct'=>$countProduct,'cart_notify'=>$cart_notify);
        $view->with($data);
    }
}