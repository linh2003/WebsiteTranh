<?php
 
namespace App\View\Composers;

use App\Models\Product;
use Illuminate\View\View;
use Illuminate\Support\Facades\Session;

class CartComposer
{
    public function __construct()
    {
       
    }
 
    public function compose(View $view)
    {
        // var_dump(Session::get('product'));
        // var_dump(Session::get('carts'));
        // die();
		$product = Session::get('product');
        $sum = Session::get('carts');
        $total = 0;
        if(!is_null($sum)){
            foreach($sum as $val){
                $total += $val;
            }
        }
        $cart_notify = Product::select('id','name','thumbnail')
        ->where('id',$product)
        ->get();

        $cart_data = array('total'=>$total,'cart_notify'=>$cart_notify);
		
        $view->with($cart_data);
    }
}