$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

function removeRow(id,url){
    if (confirm('Are you sure to delete?')) {
        $.ajax({
            type:'DELETE',
            data:{id},
            datatype:'JSON',
            url:url,
            success:function (result) {
                if (result.error==false) {
                    location.reload();
                }else{
                    alert('Delete item fail.Please try again!');
                }
            }
        });
    }
}

//upload single image
$('#uploadfile').change(function(){
    console.log('dieptv');
    const form = new FormData();
    form.append('file',$(this)[0].files[0]);
    //var url = $(location).attr('origin') + '/admin/upload';
    // var val = $(this)[0].files;
    // console.log(val);
    $.ajax({
        processData: false,
        contentType: false,
        type: 'POST',
        datatype: 'JSON',
        data: form,
        url: '/admin/upload',
        success:function (result) {
            //console.log(result);
            if (result.error==false) {
                $('#thumb').html('<img src="'+result.url+'" width="50px" />');
                $('#fileimage').val(result.url);
                if($('#uploadfile').next('.alert').length != 0){
                    $('#uploadfile').next('.alert').remove();
                }
            }else{
                $('#uploadfile').after('<div class="alert alert-danger">'+result.message+'</div>');
            }
        }
    });
});

//upload multi image
$('#uploadmulfile').change(function(){
	console.log('dieptv upload multi file');
	var len = $(this)[0].files.length;
	const form = new FormData();
	for(var i=0;i<len;i++){
		form.append('file_'+i,$(this)[0].files[i]);
	}
    $.ajax({
        processData: false,
        contentType: false,
        type: 'POST',
        datatype: 'JSON',
        data: form,
        url: '/admin/upload',
        success:function (result) {
            //console.log(result);
            if (result.error==false) {
				var arr = result.url.split(',');
				for(var i=0;i<arr.length;i++){
					$('#img_list').append('<img src="'+arr[i]+'" width="50px" />');
				}
                $('#imglist_path').val(result.url);
                if($('#uploadmulfile').next('.alert').length != 0){
                    $('#uploadmulfile').next('.alert').remove();
                }
            }else{
                $('#uploadmulfile').after('<div class="alert alert-danger">'+result.message+'</div>');
            }
        }
    });
});